package com.index;

public class barBean {
	 private String areaname;
	    private int devicenum;
	    private String date;
	    private int tradenum;
	    public String getDate() {
	        return date;
	    }
	   
	    public void setDate(String date) {
	        this.date = date;
	    }
	    public String getareaName() {
	        return areaname;
	    }
	    public void setareaName(String areaname) {
	        this.areaname = areaname;
	    }
	    public int getDeviceNum() {
	        return devicenum;
	    }
	    public void setDeviceNum(int devicenum) {
	        this.devicenum = devicenum;
	    }
	    public int getTradeNum() {
	        return tradenum;
	    }
	    public void setTradeNum(int tradenum) {
	        this.tradenum = tradenum;
	    }
}
