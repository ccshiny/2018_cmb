package com.helloBar;

public class barBean {
	 private String name;
	    private int num;
	    private String bank;
	    
	    private int type;
	    public String getBank() {
	        return bank;
	    }
	   
	    public void setBank(String bank) {
	        this.bank = bank;
	    }
	    public String getName() {
	        return name;
	    }
	    public void setName(String name) {
	        this.name = name;
	    }
	    public int getNum() {
	        return num;
	    }
	    public void setNum(int num) {
	        this.num = num;
	    }
	    public int getType() {
	        return type;
	    }
	    public void setType(int type) {
	        this.type = type;
	    }
}
